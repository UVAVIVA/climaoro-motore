# CLIMAORO Motore - Installazione

Questo archivio contiene gli script di installazione automatica del firmware CLIMAORO per ESP32-S3.

## Contenuto

- `install.bat` — script di installazione per **Windows**
- `install.sh` — script di installazione per **Linux / macOS**

## Installazione su Windows

1. Estrai questo archivio in una cartella
2. Fai **doppio clic** su `install.bat`
3. Lo script:
   - Installa Python e PlatformIO se non ci sono già
   - Scarica il codice del motore da GitHub
   - Ti chiede i tuoi dati (WiFi, IP, termostati)
   - Compila e carica il firmware sull'ESP32
   - Avvia il monitor seriale per vedere i log

## Installazione su Linux / macOS

1. Estrai questo archivio in una cartella
2. Apri un terminale nella cartella del file
3. Rendilo eseguibile e avvialo:
   ```bash
   chmod +x install.sh
   ./install.sh
   ```
4. Rispondi alle domande dello script

## Risoluzione problemi

### L'ESP32 non viene rilevato
- Usa un **cavo USB dati** (non solo ricarica)
- Prova un'altra porta USB
- Installa i driver CH343 per la tua scheda

### La compilazione fallisce
- Leggi i messaggi di errore nel terminale
- Verifica i dati inseriti (WiFi, IP, termostati)

### Lo script si blocca
- Riavvialo: i dati già inseriti non vengono persi
- Controlla la connessione internet
