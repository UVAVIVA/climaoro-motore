# CLIMAORO Motore - Installazione

Questo archivio contiene gli script di installazione automatica del firmware CLIMAORO per ESP32-S3.

## Contenuto

- `install_motore.bat` - script di installazione per **Windows**
- `install_motore.sh` - script di installazione per **Linux / macOS**

## Installazione su Windows

1. Estrai questo archivio in una cartella
2. Fai **doppio clic** su `install_motore.bat`
3. Lo script:
   - Installa Python e PlatformIO se non ci sono gia
   - Scarica il codice del motore da GitHub
   - Ti chiede i tuoi dati WiFi/IP
   - Compila e carica il firmware sull'ESP32
   - Avvia il monitor seriale per vedere i log

I termostati si aggiungono/modificano dall'app, non dall'installer.

## Installazione su Linux / macOS

1. Estrai questo archivio in una cartella
2. Apri un terminale nella cartella del file
3. Rendilo eseguibile e avvialo:
   ```bash
   chmod +x install_motore.sh
   ./install_motore.sh
   ```
4. Rispondi alle domande dello script

## Risoluzione problemi

### L'ESP32 non viene rilevato
- Usa un **cavo USB dati** (non solo ricarica)
- Prova un'altra porta USB
- Installa i driver CH343 per la tua scheda

### La compilazione fallisce
- Leggi i messaggi di errore nel terminale
- Verifica i dati inseriti (WiFi, IP)

### Lo script si blocca
- Riavvialo: i dati gia inseriti non vengono persi
- Controlla la connessione internet
